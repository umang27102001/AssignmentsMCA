// Name: UMANG KANCHAN.
// EnrollmentNumber:22/10/JC/010
// Reg. Number: 223510090519
import java.util.*;
public class DFSTraversalAdjMatrix {
    public static void dfs(int node, int V, boolean[] visited, int[][] adj) {
        visited[node] = true;
        Stack<Integer> st = new Stack<>();
        st.push(node);
        while (!st.isEmpty()) {
            int nd = st.pop();
            System.out.print(nd);
            for (int i = 0; i < V; i++) {
                if (adj[nd][i] == 1 && !visited[i]) {
                    st.push(i);
                    visited[i] = true;
                }
            }
        }
    }

    public static void main(String[] args) {

        // Given graph with V vertices & E is an array consisting of Edges. [a,b] represents an edge between vertex a & b.

        int V = 10;
        int E[][] = { { 0, 1 }, { 0, 2 }, { 0, 3 }, { 2, 4 }, { 3, 6 }, { 5, 8 }, { 4, 7 }, { 6, 7 }, { 8, 9 },
                { 9, 5 } };

        // Creating Adjacency Matrix for the given Graph.
        int[][] adj = new int[V][V];
        for (int[] it : E) {
            adj[it[0]][it[1]] = 1;
        }

        // Creating visited array
        boolean visited[] = new boolean[V];

        // calling DFS for all unvisited Vertices
        for (int i = 0; i < V; i++) {
            if (!visited[i])
                dfs(i, V, visited, adj);
        }
    }
}
