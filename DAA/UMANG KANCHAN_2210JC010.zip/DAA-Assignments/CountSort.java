// Name: UMANG KANCHAN.
// EnrollmentNumber:22/10/JC/010
// Reg. Number: 223510090519

public class CountSort {
    public static int findMax(int[] array,int n){
        int max=0;
        for(int i=1;i<n;i++){
            max=Math.max(max, array[i]);
        }
        return max;
    }
    public static void print(int[] array){
        for (int i : array) {
         System.out.print(i);   
        }
        System.out.println();
    }
    public static void main(String[] args) {
        int array[]={3,4,2,5,6,1,0};
        int n=array.length;
        int ansArray[]=new int[n];
        int max=findMax(array,n);
        int count[]=new int[max+1];
        for(int i=0;i<n;i++){
            count[array[i]]++;
        }
        for(int i=1;i<=max;i++){
            count[i]+=count[i-1];
        }
        for(int i=n-1;i>=0;i--){
            ansArray[count[array[i]]-1]=array[i];
            count[array[i]]--;
        }
        print(ansArray);
    }
}
