// Name: UMANG KANCHAN.
// EnrollmentNumber:22/10/JC/010
// Reg. Number: 223510090519
public class LinearSearch {
    public static int linearSearch(int array[],int key,int n){
        for(int i=0;i<n;i++){
            if(array[i]==key){
                return i;
            }
        }
        return -1;
    }
    public static void main(String[] args) {
        int array[]={2,4,5,1,6,-2,0,-5};
        int key=-2;
        int ans=linearSearch(array,key,array.length);
        if(ans==-1){
            System.out.println(key+" not found!!");
        }
        else{
            System.out.println("Index of key "+key+" in the array="+ans);
        }
    }
}
