// Name: UMANG KANCHAN.
// EnrollmentNumber:22/10/JC/010
// Reg. Number: 223510090519
public class QuickSort {
    private static int partition(int[] arr,int s,int e){
        int pivot=arr[s];
        int count=0;
        for(int i=s+1;i<=e;i++){
            if(arr[i]<=pivot){
                count++;
            }
        }
        int p=count+s;
        int t=arr[s];
        arr[s]=arr[p];
        arr[p]=t;
        int i=s;
        int j=e;
        while(i<=j){
            while(i<=j&&arr[i]<=pivot){
                i++;
            }
            while(i<=j&&arr[j]>pivot){
                j--;
            }
            if(i<=j){
                t=arr[i];
                arr[i]=arr[j];
                arr[j]=t;
                i++;
                j--;
            }
        }
        return p;
    }
    private static void quickSort(int[] array,int s,int e){
        if(s<e){
            int p=partition(array,s,e);
            quickSort(array, s, p-1);
            quickSort(array, p+1,e);
        }
    }
    public static void print(int[] array){
        for (int it : array) {
            System.out.print(it);
        }
        System.out.println();
    }
    public static void main(String[] args) {
        int array[]={3,4,2,5,6,1,0};
        quickSort(array,0,array.length-1);
        print(array);
    }
}
