// Name: UMANG KANCHAN.
// EnrollmentNumber:22/10/JC/010
// Reg. Number: 223510090519

public class KthMaxUsingPartition {
    public static void swap(int[] arr, int i, int j) {
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }

    public static int partition(int[] arr, int s, int e) {
        int pivot = arr[s];
        int count = 0;
        for (int i = s + 1; i <= e; i++) {
            if (arr[i] <= pivot)
                count++;
        }
        int p = count + s;
        swap(arr, s, p);
        int i = s;
        int j = e;
        while (i <= j) {
            while (i <= j && arr[i] <= pivot) {
                i++;
            }
            while (i <= j && arr[j] > pivot) {
                j--;
            }
            if (i <= j) {
                swap(arr, i, j);
                i++;
                j--;
            }
        }
        return p;
    }

    public static int Kthmax(int[] A, int p, int r, int i) {
        if (p == r) {
            return A[p];
        }
        int q = partition(A, p, r);
        int k = r - q + 1;
        if (k == i) {
            return A[q];
        } else if (i < k) {
            return Kthmax(A, q + 1, r, i);
        }
        return Kthmax(A, p, q - 1, i - k);
    }

    public static int findKthmax(int[] arr, int k) {
        return Kthmax(arr, 0, arr.length - 1, k);
    }

    public static void main(String[] args) {
        int arr[] = { 3, 1, 2, 0, 4, 5, 6, 7 };
        int k = 2;
        System.out.println("The kth maximum Element is where k=" + k + " is: " + findKthmax(arr, k));
    }
}
