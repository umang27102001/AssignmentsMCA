// Name: UMANG KANCHAN.
// EnrollmentNumber:22/10/JC/010
// Reg. Number: 223510090519
public class PostOrderTraversal {
    public static class treeNode {
        int key;
        treeNode left;
        treeNode right;

        public treeNode(int key) {
            this.key = key;
            this.left = null;
            this.right = null;
        }
    }

    public static void postOrder(treeNode node) {
        if (node == null){
            return;
        }
        postOrder(node.left);
        postOrder(node.right);
        System.out.print(node.key + " ");
    }

    public static void main(String[] args) {
        treeNode root;
        root = new treeNode(1);
        root.left = new treeNode(2);
        root.right = new treeNode(3);
        root.left.left = new treeNode(4);
        root.left.right = new treeNode(5);
        root.left.right.left = new treeNode(6);
        root.left.right.right = new treeNode(7);
        postOrder(root);
    }
}
