// Name: UMANG KANCHAN.
// EnrollmentNumber:22/10/JC/010
// Reg. Number: 223510090519
public class HeapSort {
    public static int parent(int i) {
        return i / 2;
    }

    public static int leftChild(int i) {
        return 2 * i + 1;
    }

    public static int rightChild(int i) {
        return 2 * i + 2;
    }

    public static void max_heapify(int A[], int n, int i) {
        int l = leftChild(i);
        int r = rightChild(i);
        int largest = i;
        if (l < n && A[l] > A[largest]) {
            largest = l;
        }
        if (r < n && A[r] > A[largest]) {
            largest = r;
        }
        if (largest != i) {
            int t = A[i];
            A[i] = A[largest];
            A[largest] = t;
            max_heapify(A, n, largest);
        }
    }

    public static void build_heap(int A[]) {
        int n = A.length;
        for (int i = n / 2 - 1; i >= 0; i--) {
            max_heapify(A, n, i);
        }
    }

    public static void heapSort(int[] A) {
        build_heap(A);
        int n = A.length;
        for (int i = n - 1; i > 0; i--) {
            int t = A[0];
            A[0] = A[i];
            A[i] = t;
            max_heapify(A, i, 0);
        }
    }

    public static void print(int A[]) {
        for (int i : A) {
            System.out.print(i+" ");
        }
    }

    public static void main(String[] args) {
        int array[] = { 3, 4, 2, 5, 6, -1, 0 };
        heapSort(array);
        print(array);
    }
}
