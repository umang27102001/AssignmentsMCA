// Name: UMANG KANCHAN.
// EnrollmentNumber:22/10/JC/010
// Reg. Number: 223510090519

import java.util.*;

public class BucketSort {
    public static void bucketSort(double[] A) {
        int n = A.length;
        // make B an empty list of buckets
        @SuppressWarnings("unchecked")
        LinkedList<Double>[] B = new LinkedList[n];
        for (int i = 0; i < n; i++) {
            B[i] = new LinkedList<Double>();
        }
        // insert elements into Bucket.
        for (int i = 0; i < n; i++) {
            B[(int) A[i] * n].add(A[i]);
        }

        // sort buckets
        for (int i = 0; i < n; i++) {
            Collections.sort(B[i]);
        }
        // Concatenate the buckets into A.
        int ind = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < B[i].size(); j++) {
                A[ind++] = B[i].get(j);
            }
        }
    }

    public static void main(String[] args) {
        double A[] = { 0.78, 0.17, 0.39, 0.72, 0.94, 0.21, 0.12, 0.23, 0.68 };
        bucketSort(A);
        for (double dd : A){
            System.out.print(dd + " ");}
    }
}
