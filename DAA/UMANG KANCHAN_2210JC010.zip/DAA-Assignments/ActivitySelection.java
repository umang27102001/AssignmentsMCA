// Name: UMANG KANCHAN.
// EnrollmentNumber:22/10/JC/010
// Reg. Number: 223510090519

import java.util.*;

public class ActivitySelection {
    public static void main(String[] args) {
        int start[]={1, 3, 2, 5}; int end[]={2, 4, 3, 6}; int n=4;
        List<Integer>list=new ArrayList<>();
        for(int i=1;i<n;i++){
            int keyS=start[i];
            int keyE=end[i];
            int j=i-1;
            while (j>=0&&end[j]>keyE) {
                end[j+1]=end[j];
                start[j+1]=start[j];
                j--;
            }
            end[j+1]=keyE;
            start[j+1]=keyS;
        }
        list.add(0);
        int i=0;
        for(int j=1;j<n;j++){
            if(start[j]>end[i]){
            list.add(j);
                i=j;
            }
        }
        System.out.println("The maximum number of activities that can be performed by a single person is: "+list.size());
    }
}
