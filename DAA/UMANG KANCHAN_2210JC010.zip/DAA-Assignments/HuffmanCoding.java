// Name: UMANG KANCHAN.
// EnrollmentNumber:22/10/JC/010
// Reg. Number: 223510090519
import java.util.*;
public class HuffmanCoding {
    public static class Node {
        int val;
        char ch;
        Node left;
        Node right;
    }

    public static void huffmanCode(Node rootNode, String s) {

        if (rootNode.left == null && rootNode.right == null
                && Character.isLetter(rootNode.ch)) {
            System.out.println(rootNode.ch + ":" + s);
            return;
        }

        huffmanCode(rootNode.left, s + "0");
        huffmanCode(rootNode.right, s + "1");
    }

    public static void main(String[] args) {
        int n = 7;
        char[] charArray = { 'a', 'b', 'c', 'd', 'e', 'f','g' };
        int[] charfreq = { 2,4,10,15,20,30,40 };

        PriorityQueue<Node> pq = new PriorityQueue<Node>((x, y) -> x.val - y.val);

        for (int i = 0; i < n; i++) {

            Node hufNode = new Node();

            hufNode.ch = charArray[i];
            hufNode.val = charfreq[i];

            hufNode.left = null;
            hufNode.right = null;

            pq.add(hufNode);
        }

        Node rootNode = null;

        while (pq.size() > 1) {
            Node x = pq.peek();
            pq.poll();

            Node y = pq.peek();
            pq.poll();

            Node f = new Node();
            f.val = x.val + y.val;
            f.ch = '-';
            f.left = x;
            f.right = y;
            rootNode = f;
            pq.add(f);
        }

        huffmanCode(rootNode, "");
    }

}