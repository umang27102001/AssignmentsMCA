// Name: UMANG KANCHAN.
// EnrollmentNumber:22/10/JC/010
// Reg. Number: 223510090519
class RadixSort {

    private static int findMax(int arr[], int n) {
        int max = arr[0];
        for (int i = 1; i < n; i++) {
            max = Math.max(max, arr[i]);
        }
        return max;
    }

    private static void countSort(int arr[], int n, int pow) {
        int ansArray[] = new int[n];
        int count[] = new int[10];

        for (int i = 0; i < n; i++) {
            count[(arr[i] / pow) % 10]++;
        }

        for (int i = 1; i < 10; i++) {
            count[i] += count[i - 1];
        }

        for (int i = n - 1; i >= 0; i--) {
            ansArray[count[(arr[i] / pow) % 10] - 1] = arr[i];
            count[(arr[i] / pow) % 10]--;
        }

        for (int i = 0; i < n; i++) {
            arr[i] = ansArray[i];
        }
    }

    static void radixSort(int arr[], int n) {
        int m = findMax(arr, n);

        for (int pow = 1; m / pow > 0; pow *= 10) {
            countSort(arr, n, pow);
        }
    }

    static void print(int arr[], int n) {
        for (int i : arr) {
            System.out.print(i + " ");
        }
    }

    public static void main(String[] args) {
        int arr[] = { 101, 38, 345, 221, 175, 36, 51, 680, 122 };
        int n = arr.length;
        radixSort(arr, n);
        print(arr, n);
    }
}
