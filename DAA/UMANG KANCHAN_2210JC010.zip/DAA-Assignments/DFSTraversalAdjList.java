// Name: UMANG KANCHAN.
// EnrollmentNumber:22/10/JC/010
// Reg. Number: 223510090519

import java.util.*;
public class DFSTraversalAdjList {
    public static void dfs(int node,int V,boolean[]visited,ArrayList<LinkedList<Integer>> adj){
        visited[node] = true;
        Stack<Integer> st = new Stack<>();
        st.push(node);
        while (!st.isEmpty()) {
            int nd = st.pop();
            System.out.print(nd);
            for(int it:adj.get(nd)){
                if(!visited[it]){
                    st.push(it);
                    visited[it]=true;
                }
            }
        }
    }
    public static void main(String[] args) {
        // Given graph with V vertices & E is an array consisting of Edges. [a,b] represents an edge between vertex a & b.
        int V = 10;
        int E[][] = { { 0, 1 }, { 0, 2 }, { 0, 3 }, { 2, 4 }, { 3, 6 }, { 5, 8 }, { 4, 7 }, { 6, 7 }, { 8, 9 },
                { 9, 5 } };

        //Creating Adjacency List for the given Graph.
        ArrayList<LinkedList<Integer>> adj = new ArrayList<LinkedList<Integer>>();
        for (int i = 0; i < V; i++) {
            adj.add(new LinkedList<>());
        }
        for (int i = 0; i < E.length; i++) {
            adj.get(E[i][0]).add(E[i][1]);
        }

        //Creating visited array
        boolean[]visited=new boolean[V];

        // calling DFS for all unvisited Vertices
        for(int i=0;i<V;i++){
            if(!visited[i]) dfs(i,V,visited,adj);
        }
    }
}
