// Name: UMANG KANCHAN.
// EnrollmentNumber:22/10/JC/010
// Reg. Number: 223510090519

import java.util.*;

public class BFSTraversalAdjList {
    public static void bfs(int node,int V,boolean[]visited,ArrayList<LinkedList<Integer>> adj ){
        Queue<Integer>q=new LinkedList<>();
        q.add(node);
        visited[node]=true;
        while(!q.isEmpty()){
            int nd=q.remove();
            System.out.print(nd);
            for(Integer it:adj.get(nd)){
                if(!visited[it]){
                    q.add(it);
                    visited[it]=true;
                }
            }
        }
    }
    
    public static void main(String[] args) {
        // Given graph with V vertices & E is an array consisting of Edges. [a,b] represents an edge between vertex a & b.

        int V = 10;
        int E[][] = { { 0, 1 }, { 0, 2 }, { 0, 3 }, { 2, 4 }, { 3, 6 }, { 5, 8 }, { 4, 7 }, { 6, 7 }, { 8, 9 },
                { 9, 5 } };

        //Creating Adjacency List for given Graph.
        ArrayList<LinkedList<Integer>> adj = new ArrayList<LinkedList<Integer>>();
        for (int i = 0; i < V; i++) {
            adj.add(new LinkedList<>());
        }
        for (int i = 0; i < E.length; i++) {
            adj.get(E[i][0]).add(E[i][1]);
        }

        //Creating visited array
        boolean[]visited=new boolean[V];

        // calling BFS for all unvisited Vertices
        for(int i=0;i<V;i++){
            if(!visited[i]) bfs(i,V,visited,adj);
        }   
    }
}
