// Name: UMANG KANCHAN.
// EnrollmentNumber:22/10/JC/010
// Reg. Number: 223510090519
public class FindMinMax {
    public static void main(String[] args) {
        int arr[] = { 1, 3, 2, 4, -5, 5, 7, 6, 10 };
        int max = arr[0];
        int min = arr[0];
        for (int i = 1; i < arr.length; i++) {
            if (arr[i] > max) {
                max = arr[i];
            } else if (arr[i] < min) {
                min = arr[i];
            }
        }
        System.out.println("Maximum= " + max + " and Minimum= " + min);

    }
}
