// Name: UMANG KANCHAN.
// EnrollmentNumber:22/10/JC/010
// Reg. Number: 223510090519

import java.util.Arrays;

public class BinarySearch {
    public static int binarySearch(int array[], int key, int n) {
        int s = 0;
        int e = n - 1;
        while (s <= e) {
            int mid = s + (e - s) / 2;
            if (array[mid] == key) {
                return mid;
            } else if (array[mid] < key) {
                s = mid + 1;
            } else {
                e = mid - 1;
            }
        }
        return -1;
    }

    public static void main(String[] args) {
        int array[] = { -7, 0, 1, 5, 7, 8, 9 };
        int key = 5;
        Arrays.sort(array);
        int ans = binarySearch(array, key, array.length);
        if (ans == -1) {
            System.out.println(key + " not found!!");
        } else {
            System.out.println("Index of key " + key + " in the array= " + ans);
        }
    }
}
