// Name: UMANG KANCHAN.
// EnrollmentNumber:22/10/JC/010
// Reg. Number: 223510090519

public class MatrixChainMultiplication {
    public static void MatrixChainOrder(int[] p, int n, int[][] m, int[][] s) {
        for (int i = 0; i < n - 1; i++) {
            m[i][i] = 0;
        }
        for (int l = 2; l < n; l++) {
            for (int i = 0; i < n - l; i++) {
                int j = i + l - 1;
                m[i][j] = Integer.MAX_VALUE;
                for (int k = i; k < j; k++) {
                    int q = m[i][k] + m[k + 1][j] + p[i] * p[k + 1] * p[j + 1];
                    if (q < m[i][j]) {
                        m[i][j] = q;
                        s[i][j] = k;
                    }
                }
            }
        }
    }

    public static void PrintOptimalParens(int[][] s, int i, int j) {
        if (i == j) {
            System.out.print("A" + (i + 1));
        } else {
            System.out.print('(');
            PrintOptimalParens(s, i, s[i][j]);
            PrintOptimalParens(s, s[i][j] + 1, j);
            System.out.print(')');
        }
    }

    public static void main(String[] args) {
        int n = 5;
        int p[] = { 1, 2, 3, 4, 5 };
        int m[][] = new int[n - 1][n - 1];
        int s[][] = new int[n - 1][n - 1];
        MatrixChainOrder(p, n, m, s);
        PrintOptimalParens(s, 0, n - 2);

    }
}
