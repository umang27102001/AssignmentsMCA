// Name: UMANG KANCHAN.
// EnrollmentNumber:22/10/JC/010
// Reg. Number: 223510090519

public class LongestCommonSubsequence {
    public static int count = 0;

    public static void lcs_length(String text1, String text2, int[][] c, char b[][]) {
        int m = text1.length();
        int n = text2.length();
        for (int i = 0; i <= m; i++) {
            c[i][0] = 0;
        }
        for (int i = 0; i <= n; i++) {
            c[0][i] = 0;
        }
        for (int i = 1; i <= m; i++) {
            for (int j = 1; j <= n; j++) {
                if (text1.charAt(i - 1) == text2.charAt(j - 1)) {
                    c[i][j] = c[i - 1][j - 1] + 1;
                    b[i][j] = '1';
                } else if (c[i - 1][j] >= c[i][j - 1]) {
                    c[i][j] = c[i - 1][j];
                    b[i][j] = '2';
                } else if (c[i - 1][j] < c[i][j - 1]) {
                    c[i][j] = c[i][j - 1];
                    b[i][j] = '3';
                }
            }
        }
    }

    public static void print(char[][] b, String text1, int i, int j) {
        if (i == 0 || j == 0) {
            return;
        }
        if (b[i][j] == '1') {
            print(b, text1, i - 1, j - 1);
            System.out.print(text1.charAt(i - 1));
            count++;
        } else if (b[i][j] == '2') {
            print(b, text1, i - 1, j);
        } else {
            print(b, text1, i, j - 1);
        }
    }

    public static void main(String[] args) {
        String s1 = "DYNAMICPROGRAMMING";
        String s2 = "GREEDYAPPROACH";
        int m = s1.length();
        int n = s2.length();
        int c[][] = new int[m + 1][n + 1];
        char b[][] = new char[m + 1][n + 1];
        lcs_length(s1, s2, c, b);
        System.out.println("The Longest Common Subsequence Of Given 2 Strings is:");
        print(b, s1, s1.length(), s2.length());
        System.out.println("\nThe length of the Longest Common Subsequence Of Given 2 Strings is: " + count);
    }
}
